var new_lang = {
    
"lt0": "Hochkonzentriertes",
"lt1": "cannabisöl",

"lt2": "Befreit von Prostatitis in nur <span>28 Tagen</span>",

"lt3": "Beseitigt einen pathogenen Verhalt<br> in der Prostata",

"lt4": "Wirkt abschwellend und entzündungshemmend",

"lt5": "Normalisiert das Wasserlassen",

"lt6": "Führt den Sexualtrieb zurück",

"lt7": "Bestellen Sie jetzt mit einem Rabatt von 50%<div class=\"price-area\"><div class=\"price_main\"><span class=\"price_main_value\">49</span><span class=\"price_main_currency\">EUR</span></div><div class=\"price_old\"><span class=\"price_main_value\">98</span><span class=\"price_main_currency\">EUR</span></div></div>",



"lt21": "Mit Rabatt bestellen",

"lt22": "Entdeckung<br> der letzten Jahre",

"lt23": "Empfehlungen von<br> führenden Urologen",

"lt24": "34785 Männer wurden<br> schon gesund",

"lt25": "Klinisch bewiesene <br>Wirksamkeit",

"lt26": "Haben Sie wenigstens ein Symptom?",

"lt27": "Überprüfen Sie es",

"lt28": "Sie stehen nachts häufig auf, um auf die Toilette zu gehen",

"lt29": "Erschwertes Wasserlassen",

"lt30": "Ziehende Schmerzen<br> im Unterleib",

"lt31": "Es entstanden brennende und stechende Schmerzen beim Urinieren",

"lt32": "Das Libido<br> ist verschwunden",

"lt33": "Die Potenz wurde <br>schwach",

"lt34": "Vorzeitiger<br> Samenerguss",

"lt35": "Unterdrückte Stimmung, Minderung der Erwerbsfähigkeit",

"lt36": "Jedes von diesen Symptomen besagt, dass chronische Prostatitis besteht.<br> Das ist eine der gefährlichsten und meistverbreiteten Erkrankung der Männer!",

"lt37": "Was wird geschehen, wenn man chronische Prostatitis nicht behandelt?",

"lt38": "Hohes Risiko des Adenoms <br>und Krebses der Prostata",

"lt39": "Vollständiges Fehlen des<br> Libido",

"lt40": "Unfruchtbarkeit<br> und Einsamkeit",

"lt41": "Probleme mit<br> dem Wasserlassen",

"lt42": "Solange es nicht<br> zu spät wurde",

"lt43": "sie können <br>alles verändern!",

"lt44": "Der Harndrang <br>wird häufiger werden",

"lt45": "Verschlimmerung der Schmerzen",

"lt46": "Schnelle Alterung<br> des gesamten Organismus",

"lt47": "Wie wird Ihnen Cannabisöl helfen?",

"lt48": "<span>Normalisierung des Wasserlassens</span> Starke entzündungshemmende Eigenschaften tragen zu schneller Abschwellung bei, wodurch die Harnausscheidungswege frei werden.",

"lt49": "<span>Vorbeugung des Adenoms und Prostatakrebses</span> Stoffe, die in der Rezeptur des Öls enthalten sind, verzögern die Entwicklung der Krebszellen und beugen ihrer Teilung vor.",

"lt50": "<span>Behandlung der Prostatitis</span> Cannabisöl ist in der Lage, den infektiösen Agenten in der Prostata zu beseitigen und die Abwehrkraft der Drüse zu verstärken. Das Öl weist eine wesentlich größere Wirksamkeit bei der Behandlung der Prostatitis auf, als traditionelle Arzneimittel.",

"lt51": "<span>+ Zusätzlich Wiederherstellung der Potenz</span> Bei kurförmiger Einnahme, behandelt Cannabisöl nicht nur die Prostatitis, sondern es stellt auch die Potenz wieder her und trägt zur Verbesserung der Erektion und der Dauer des Geschlechtsverkehrs bei. Es steigert auch das Libido und den Sexualtrieb.",

"lt52": "Mit Rabatt bestellen",

"lt53": "<span>Einzigartige </span>Kombination der Inhaltsstoffe im Canabisöl",

"lt54": "<span class=\"wow fadeInDown\" style=\"visibility: hidden; animation-name: none;\"></span>Omega-9, Omega-6, Omega-3 in dem gesundheitsförderndsten Verhältnis",

"lt55": "Zerstören die Cholesterinablagerungen und Plaque 40 Mal besser, als Fischöl und 30 Mal schneller, als jegliche andere pflanzliche Öle.",

"lt56": "<span class=\"wow fadeInDown\" style=\"visibility: hidden; animation-name: none;\"></span>Proteine",

"lt57": "Unterstützen die Funktion des Herz-Kreislaufsystems, verfügen über allgemein festigende und abwehrkraftfördernde Wirkungen.",

"lt58": "<span class=\"wow fadeInDown\" style=\"visibility: hidden; animation-name: none;\"></span>Chlorophyll",

"lt59": "Steigert die Anzahl der Erythrozyten, leitet die Salze der Schwermetalle aus dem Organismus heraus, widersetzt sich der pathogenen Einwirkung von Kanzerogenen.",

"lt60": "<span class=\"wow fadeInDown\" style=\"visibility: hidden; animation-name: none;\"></span>Natürliche Antioxidantien",

"lt61": "Leiten freie Radikale aus dem Organismus heraus, steigern den Tonus der Gefäßwände, schützen vor der Entwicklung der Atherosklerose.",

"lt62": "<span class=\"wow fadeInDown\" style=\"visibility: hidden; animation-name: none;\"></span>Große Anzahl von Vitaminen А, B, С, Е, К, D",

"lt63": "Normalisieren die Stoffwechselprozesse, regeln die Produktion des Hämoglobins und der Erythrozyten, festigen die Abwehrkraft, stellen das Nervensystem wieder her",

"lt64": "<span class=\"wow fadeInDown\" style=\"visibility: hidden; animation-name: none;\"></span>Gerbstoffe",

"lt65": "Verstärken das Gefäßnetz, beugen die Gefäßschäden und innere Blutungen vor, einschließlich im Gehirn",

"lt66": "<span class=\"wow fadeInDown\" style=\"visibility: hidden; animation-name: none;\"></span>Mineralien Mangan, Magnesium, Eisen, Zink, Phosphor, Kalzium",

"lt67": "Verbessern die Qualität des Blutes, steigern die Elastizität der Gefäßwände, vermindern die Sensibilität der Arterien gegenüber den gefäßverengenden Impulsen.",

"lt68": "<span class=\"wow fadeInDown\" style=\"visibility: hidden; animation-name: none;\"></span>Phytosterole",

"lt69": "Vermindern die Unruhe, dilatieren die Gefäße, beugen Schwankungen des Blutdrucks vor",

"lt70": "Meinung der Experten über das Cannabisöl",

"lt71": "Peter Lang",

"lt72": "FA für Urologie und Andrologie <br> Oberarzt",

"lt73": "Heute ziehen immer mehr Fachkräfte die Behandlung der Erkrankungen mit Naturheilverfahren vor. Sie schaden anderen Organen nicht und weisen einen langfristigeren Behandlungserfolg auf.",

"lt74": "Das Cannabisöl, wie die klinischen Studien gezeigt haben, ist speziell für die Gesundung von Männern geschaffen. Die Anzahl und die Verhältnisse seiner Stoffe sind so ausgeglichen, dass sie fähig sind, Prostatitis zu behandeln und die Entwicklung des Adenoms und Prostatakrebs vorzubeugen. Es hat eine bessere Wirkung, als Antibiotika und chemische Arzneimittel, die in der traditionellen Behandlung von dieser Erkrankung verwendet werden.",

"lt75": " In der letzten Zeit, empfehle ich meinen Patienten immer häufiger nämlich das XX, deren Erfahrungen die Besten sind. Die Ergebnisse seiner Anwendung überwältigen manchmal sogar erfahrene Ärzte.",

"lt76": "Klinische Studien des Cannabisöls",

"lt77": "Die Tests des Cannabisöls wurden auf der Basis des Institutes der männlichen Gesundheit in Jersey, USA, 2017 <br>mit 750 Freiwilligen durchgeführt. Die statistisch relevante Ungenauigkeit beträgt max. 2,3 %.",

"lt78": "<span>88% </span><div class=\"bage-wrapper\"><span>der Probanden</span></div> Beseitigung der Entzündung<br> in der Prostata",

"lt79": "<span>96%</span><div class=\"bage-wrapper\"><span> der Probanden</span></div> Normalisierung des Wasserlassens",

"lt80": "<span>93%</span><div class=\"bage-wrapper\"><span> der Probanden</span></div> Wiederherstellung der natürlichen Potenz",

"lt81": "<span>98%</span><div class=\"bage-wrapper left\"><span> der Probanden</span></div> Verstärkung des Sexualtriebs gleich nach der Einnahme",

"lt82": "<span>100%</span><div class=\"bage-wrapper left\"><span> der Probanden </span></div> Steigerung des Lebenstonus",

"lt83": "<span>100%</span><div class=\"bage-wrapper left\"><span> der Probanden </span></div> Fehlen von negativen Folgen",

"lt84": "Bestellen, solange auf Vorrat",

"lt85": "<span>Das Cannabisöl</span> ist ein einzigartiges modernes Erzeugnis für die Behandlung der Prostatitis",

"lt86": "Das Cannabisöl ist die Entdeckung der letzten Jahre. Wie die vielzähligen klinischen Studien, die zwischen 2016 und 2018 durchgeführt wurden, gezeigt haben, ist es fähig, die Prostata zu heilen und die Prostatitis besser zu behandeln, als Antibiotika und chemische Arzneimittel aus der Apotheke. Das Cannabisöl ist 100% naturales Produkt, das dem Organismus nicht schadet und macht ihn noch gesünder.",

"lt87": "3 Schritte auf dem Weg zur Gesundung der Prostata",


"lt88": "Schmerz, Stechen und Brennen in der Leiste<br> und dem Kreuz hören auf. Der Sexualtrieb steigt an",

"lt89": "Die Entzündung klingt ab.<br> Der häufige Harndrang vergeht, es entfällt die Notwendigkeit, nachts aufzustehen",

"lt90": "Die Potenz<br> wird wiederhergestellt, der Organismus wird gefestigt, die Prostatitis kehrt nicht zurück.",

"lt91": "Wie wird es <br>eingenommen?",

"lt92": "À 1 Kapsel 2-3 Mal <br>täglich",

"lt93": "Täglich<br> im Laufe der gesamten Kur einnehmen",

"lt94": "Die Kur kann<br> bei fortgeschrittener <br> Form der Prostatitis wiederholt werden",

"lt95": "Erfahrungen der Käufer",

"lt96": "Ich habe die Prostatitis sowohl mit Volksmethoden, als auch mit Tabletten behandelt. Geholfen hat es kaum. Ich habe gar keine Hoffnung mehr gehabt, konnte nachts kaum noch schlafen – die Schmerzen quälten mich, und auf die Toilette musste ich beinahe alle fünf Minuten. Dabei war es eine echte Prüfung, zu urinieren. Natürlich hatte ich aus diesem Grunde riesige Probleme beim Sex. In einem Magazin habe ich über die gesundheitsfördernden Eigenschaften des Cannabisöls für Männer gelesen. Ich habe beschlossen, es mal auszuprobieren. Am Ende hatte ich keine Beschwerden mehr. Es hat sich herausgestellt, dass man genau damit beginnen musste. Nun bin ich absolut gesund!",

"lt97": "Christoph Wulff<br> 47 Jahre",

"lt98": "Ein ausgezeichnetes Mittel. Der Schmerz beim Sex mit der jungen Frau war so stark, dass ich es nicht aushalten konnte. Natürlich hörten wir auf, Sex zu treiben. Gelitten habe sowohl ich, als auch sie. Ein bekannter hat mir einst mal empfohlen, XX auszuprobieren. Er hat seinerzeit die Prostatitis damit ausgeheilt. Ich habe es also bestellt. In 3 Tagen kam die Packung an und ich habe mit der Einnahme begonnen. In einer Woche hörten nicht nur die Schmerzen auf, sondern auch die Potenz wurde so, wie zu Jugendzeit. Und auch noch der Wunsch, Sex zu treiben, der dann riesig wurde! Das Interesse am anderen Geschlecht, das mit dem zunehmenden Alter abzuklingen begonnen hat, stieg nun an. In Wirklichkeit hat dieses Öl mein Privatleben gerettet! Es hat mir sehr gefallen!",

"lt99": "Alexander Graf<br>61 Jahre",

"lt100": "Eine erstaunliche Weise der Behandlung der Prostatitis! Mein Hausarzt hat es mir empfohlen. In Wirklichkeit hoffte ich nicht allzu sehr, dass es helfen wird. Im Endeffekt ist aber die Prostatitis, die mich mehr, als 6 Jahre geplagt hat, nun vollkommen vorbei. Seit 3 Monaten habe ich keine mehr. Auf die Toilette kann ich nun problemlos gehen, wie es auch früher war. Die Potenz wurde stärker, ich kann nun viel längeren Sex haben und bekomme viel mehr Vergnügen davon. Übrigens, ich bin schon 61 Jahre alt. Ich empfehle das XX allen! Viel besser, als gewöhnliche Tabletten!",

"lt101": "Helmut Burhardt<br> 55 Jahre",

"lt102": "Ich habe die Prostatitis sowohl mit Volksmethoden, als auch mit Tabletten behandelt. Geholfen hat es kaum. Ich habe gar keine Hoffnung mehr gehabt, konnte nachts kaum noch schlafen – die Schmerzen quälten mich, und auf die Toilette musste ich beinahe alle fünf Minuten. Dabei war es eine echte Prüfung, zu urinieren. Darum, hatte ich beim Sex riesige Probleme. In einem Magazin habe ich über die gesundheitsfördernden Eigenschaften des Cannabisöls für Männer gelesen. Ich habe beschlossen, es mal auszuprobieren. Endlich habe ich keine Beschwerden mehr. Es hat sich herausgestellt, dass man genau damit beginnen musste. Nun bin ich absolut gesund!",

" lt103": "Christoph Wulff <br>47 Jahre",

"lt104": "Ein ausgezeichnetes Mittel. Der Schmerz beim Sex mit der jungen Frau war so stark, dass ich es nicht aushalten konnte. Natürlich hörten wir auf, Sex zu treiben. Gelitten habe sowohl ich, als auch sie. Ein bekannter hat mir einst mal empfohlen, XX auszuprobieren. Er hat seinerzeit die Prostatitis damit ausgeheilt. Ich habe es also bestellt. In 3 Tagen kam die Packung an und ich habe mit der Einnahme begonnen. In einer Woche hörten nicht nur die Schmerzen auf, sondern auch die Potenz wurde so, wie zu Jugendzeit. Und auch noch der Wunsch, Sex zu treiben, der dann riesig wurde! Das Interesse am anderen Geschlecht, das mit dem zunehmenden Alter abzuklingen begonnen hat, stieg nun an. In Wirklichkeit hat dieses Öl mein Privatleben gerettet! Es hat mir sehr gefallen!",

"lt105": " Alexander Graf <br>61 Jahre",

"lt106": "Eine erstaunliche Weise der Behandlung der Prostatitis! Mein Hausarzt hat es mir empfohlen. In Wirklichkeit hoffte ich nicht allzu sehr, dass es helfen wird. Im Endeffekt, ist aber die Prostatitis, die mich mehr, als 6 Jahre geplagt hat, nun vollkommen vorbei. Seit 3 Monaten habe ich keine mehr. Auf die Toilette kann ich nun problemlos gehen, wie es auch früher war. Die Potenz wurde stärker, ich kann nun viel längeren Sex haben und bekomme viel mehr Vergnügen davon. Übrigens, ich bin schon 61 Jahre alt. Ich empfehle das XX allen! Viel besser, als gewöhnliche Tabletten!",

"lt107": "Helmut Burhardt<br> 55 Jahre",

"lt108": "Ich habe die Prostatitis sowohl mit Volksmethoden, als auch mit Tabletten behandelt. Geholfen hat es kaum. Ich habe gar keine Hoffnung mehr gehabt, konnte nachts kaum noch schlafen – die Schmerzen quälten mich, und auf die Toilette musste ich beinahe alle fünf Minuten. Dabei war es eine echte Prüfung, zu urinieren. Natürlich, hatte ich aus diesem Grunde riesige Probleme beim Sex. In einem Magazin habe ich über die gesundheitsfördernden Eigenschaften des Cannabisöls für Männer gelesen. Ich habe beschlossen, es mal auszuprobieren. Endlich habe ich keine Beschwerden mehr. Es hat sich herausgestellt, dass man genau damit beginnen musste. Nun bin ich absolut gesund!",

"lt109": " Christoph Wulff <br> 47 Jahre",

"lt110": "Hochkonzentriertes Cannabisöl",

"lt112": "Befreit von Prostatitis in nur <span>28 Tagen</span>",

"lt113": "Beseitigt einen pathogenen Verhalt<br> in der Prostata",

"lt114": "Wirkt abschwellend und entzündungshemmend",

"lt115": "Normalisiert das Wasserlassen",

"lt116": "Führt den Sexualtrieb zurück",

"lt117": "Bestellen Sie jetzt mit einem Rabatt von 50% <div class=\"price-area\"><div class=\"price_main\"><span class=\"price_main_value\">49 </span><span class=\"price_main_currency\">EUR </span></div><div class=\"price_old\"><span class=\"price_main_value\">98 </span><span class=\"price_main_currency\">EUR</span></div></div>",

"lt131": "Mit Rabatt bestellen",

"lt132": "<span>Sie können das</span> Cannabisöl jetzt gleich bestellen",

"lt133": "Hinterlassen Sie eine Anfrage auf unserer Webseite",

"lt134": "Wir werden Sie binnen 5 Minuten <br>zwecks Bestätigung der Bestellung zurückrufen",

"lt135": "Wir werden das Öl per Kurier in 3 bis 7 Tagen liefern",

"lt136": "Datenschutzpolitik",

"lt137": "Rückruf bestellen",

"lt138": "© 2019 Cannabis Oil. Alle Rechte sind geschützt"

};
    

function Translater () {
 for (class_name in new_lang) {
 var elements = document.getElementsByClassName(class_name);
 if (elements.length) {
 for (key in elements) {
 elements[key].innerHTML = new_lang[class_name];
 }
 }
 }
 };